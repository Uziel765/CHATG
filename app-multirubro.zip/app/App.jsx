import { useState } from "react";

export default function App() {
  const [zona, setZona] = useState("");
  const [localidad, setLocalidad] = useState("");
  const [codigo, setCodigo] = useState("");
  const [mensaje, setMensaje] = useState("");

  const handleSubmit = async () => {
    if (!zona || !localidad || !codigo) {
      setMensaje("Faltan completar campos");
      return;
    }

    try {
      const respuesta = await fetch("https://api.sheetmonkey.io/form/YOUR_FORM_ID", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Zona: zona,
          Localidad: localidad,
          Codigo: codigo,
          Fecha: new Date().toLocaleString(),
        }),
      });

      if (respuesta.ok) {
        setMensaje("Datos enviados correctamente ✅");
        setCodigo("");
      } else {
        setMensaje("Error al enviar los datos ❌");
      }
    } catch (error) {
      setMensaje("Error de red ❌");
    }
  };

  return (
    <main style={{ padding: 20, backgroundColor: '#f3f3f3', minHeight: '100vh' }}>
      <h1>Registro de Productos</h1>
      <input placeholder="Zona" value={zona} onChange={(e) => setZona(e.target.value)} /><br />
      <input placeholder="Localidad" value={localidad} onChange={(e) => setLocalidad(e.target.value)} /><br />
      <input placeholder="Código escaneado" value={codigo} onChange={(e) => setCodigo(e.target.value)} /><br />
      <button onClick={handleSubmit}>Enviar a Sheets</button>
      {mensaje && <p>{mensaje}</p>}
    </main>
  );
}
