# ZENDA

App multi-rubro: almacenes, kioscos, mensajerías, restaurantes y más.