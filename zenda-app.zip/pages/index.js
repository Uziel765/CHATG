export default function Home() {
  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      height: "100vh",
      fontFamily: "sans-serif"
    }}>
      <h1>Bienvenido a ZENDA</h1>
      <p>Tu app multi-rubro. Empecemos...</p>
    </div>
  )
}